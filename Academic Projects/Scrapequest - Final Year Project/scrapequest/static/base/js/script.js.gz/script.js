function toggleKeywords() {
    var container = document.getElementById("keyword-buttons-container");
    if (container.style.display === "block") {
        container.style.display = "none";
    } else {
        container.style.display = "block";
    }
}


/* buttons */


